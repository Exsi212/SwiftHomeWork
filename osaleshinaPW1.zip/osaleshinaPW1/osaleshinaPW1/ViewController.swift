//
//  ViewController.swift
//  osaleshinaPW1
//
//  Created by Ольга Алешина on 03.10.2023.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonWanPressed(_ sender: Any) {
        let randomColor1 = getRandomColor()
        let randomColor2 = getRandomColor()
        let randomColor3 = getRandomColor()
        
        view1.backgroundColor = randomColor1
        view2.backgroundColor = randomColor2
        view3.backgroundColor = randomColor3
        
        view1.layer.cornerRadius = 5.0
        view2.layer.cornerRadius = 15.0
        view3.layer.cornerRadius = 45.0
        
        UIView.animate(withDuration: 0.30) {
        self.view1.backgroundColor = randomColor1
        self.view2.backgroundColor = randomColor2
        self.view3.backgroundColor = randomColor3
               }
    }
    func getRandomColor() -> UIColor {
           
            let red = CGFloat.random(in: 0...1)
            let green = CGFloat.random(in: 0...1)
            let blue = CGFloat.random(in: 0...1)

            
            return UIColor(red: red, green: green, blue: blue, alpha: 1.0)
        }
}

